# =============================================================================
# This experiment was created by Borja Aguado.
# Use of this script and debug is encouraged  
# =============================================================================

# =============================================================================
# Basic libraries
# =============================================================================

from psychopy import visual, event
import pyglet
import pywavefront
import random
from pyglet import app
from pyglet import clock
from pyglet.gl import *
from pyglet.window import mouse, key
import sys
from pyglet_utils import *
from math import *
from psychopy import data, core, gui, sound
import math
from pywavefront import visualization

# =============================================================================
# Real screen dimensions
# =============================================================================

SCREENDISTANCE = 0.7
SCREEN_WIDTH_M = 0.324
SCREEN_HEIGHT_M = 0.225
nearest = 0.001; # Nearest visible point
furthest = 20; # Furthest visible point 
IOD = offsetX = x = 0


WIDTH = 1024
HEIGHT = 768

window1 = pyglet.window.Window(width = WIDTH, height= HEIGHT)
gl_setup1()
glClearColor(0, 0, 0, 1)
seed(80085)
#window1.set_fullscreen(screen=screen1)

# =============================================================================
# Window 1. Screen 1: right
# =============================================================================
@window1.event
def on_resize(width, height):
    glViewport(0, 0, width, height)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    
    ## Offset X: IOD
    z = SCREENDISTANCE
    x = 0

    #Visibility of the camera
    glFrustum((nearest / z) * (-x - 0.5 * SCREEN_WIDTH_M),  # Left
              (nearest / z) * (-x + 0.5 * SCREEN_WIDTH_M),  # Right
              (nearest / z) * (-0.5 * SCREEN_HEIGHT_M),     # Bottom 
              (nearest / z) * (0.5 * SCREEN_HEIGHT_M),      # Top
              nearest, furthest)
    
    glTranslatef(0, 0, -z); 
    # z=0 is the screen in world coordinates
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    return pyglet.event.EVENT_HANDLED 
    
@window1.event
def on_draw():
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
	glLoadIdentity()

	if visible:
		glPushMatrix()
		glTranslatef(0, 0, Zi + ball_z) 
		visualization.draw(ball_object)
		glPopMatrix()



ball_object = pywavefront.Wavefront('Objects/tennis_congruent.obj')
Conditions = "3D_UA.xlsx"
reps = 1

# =============================================================================
# Create repetitions
# =============================================================================
conditions = data.importConditions(Conditions)
trials = data.TrialHandler(conditions,reps)

# =============================================================================
# Stimuli parameters
# =============================================================================
nTrials = trials.nTotal
next(trials)

## Ball's initial position 
vz = ball_x = trials.thisTrial["vz"] 
label = trials.thisTrial["label"] 



nDone = 0                                       # Number of trials done
tinit = 0.0                                     # Initiation time for each trial tinit=clock.tick()
timeStill = 1 						            # Time during which the object is not moving (mainly to fixate)
elapsedtime = 0.0                               # Elapsed time of target displayed
visible = 1
ball_z = 0
active = 0
response = -1
response_flag = 0

# =============================================================================
# Setup trial parameters 
# =============================================================================
def setupTrial():
	global Zi, vz, ball_z, label, elapsedtime, visible, response, response_flag

	Zi = -2
	vz = trials.thisTrial["vz"] 
	label = trials.thisTrial["label"] 
	ball_z = 0
	visible = 0
	response = -1
	response_flag = 0

	print ("Trial:", trials.thisN + 1, "; Vz", vz)

	if sys.platform == 'win32':
	# On Windows, the best timer is time.clock
		tinit = time.clock()
	else:
	# On most other platforms the best timer is time.time
		tinit = time.time()

	elapsedtime = 0.0
	t = 0


# =============================================================================
# Create movement (Update position of the target)
# =============================================================================
def update_positions(dt):
	global elapsedtime, visible, ball_z 

	elapsedtime += dt
	if elapsedtime>timeStill:
		visible = 1
		# Position
		ball_z += dt * vz

trial_datafile = openDataFile("demo_UA_")


print ("trial","vz","response", file = trial_datafile)

def save_trial():
	print (nDone,vz,response, file = trial_datafile)


def safe_forced_close():
    window1.close()
    trial_datafile.close()
    #PupilLabs(Windows = Windows, Part = "End")
    app.exit()
    print ("Safely closed. Bye!")

def endTrial():
    global trials, nDone
    nDone += 1   
    save_trial()
    if nDone < trials.nTotal:
        next(trials)
        setupTrial()
    else:
        safe_forced_close()


@window1.event
def on_key_press(symbol, modifiers):
	global active, response
	key = symbol - 48
	#print(symbol)
	if key == 0:
		active = 1
	if response_flag:
		if symbol == 115:
			response = 1
			endTrial()
		if symbol == 110:
			response = 0
			endTrial()

	if symbol == 65307:
	 	safe_forced_close()
        
     
# =============================================================================
# Update world
# =============================================================================
def update(dt):
	global visible, response_flag
	if active == 1:
		update_positions(dt)
		if elapsedtime > 2:
			visible = 0
			response_flag = 1

	
pyglet.clock.schedule(update)


# =============================================================================
# Start program
# =============================================================================
#core.wait(5)
setupTrial() # to start 1st trial
app.run()

