from __future__ import division
import numpy
from random import *
import time
from itertools import *
import os
from OpenGL.GL import *
from OpenGL.GLU import *
from math import pi, sin, cos

from pyglet.gl import *

def openDataFile(subject):
    if not os.path.exists('data'):
        os.makedirs('data')
    timeAndDateStr = time.strftime("%d%b%Y_%H-%M", time.localtime()) 
    dataFile=open('data/' + subject + timeAndDateStr  + '.txt', 'w')
    return dataFile
    
def createList(dicts):
    return list(dict(izip(dicts, x)) for x in product(*dicts.itervalues()))

# Objects ######
def circle(x, y, r, n, c, b):
    """ Adds a vertex list of circle polygon to batch and returns it. """
    rad = 2*pi / n # getting 360 / n in radians
    index = list(chain.from_iterable( (0, x-1, x)  for x in range(2, n+1) ))
    index.extend( (0, 1, n) ) # end of fan
    p = x, y # adding center of fan
    for i in range(1, n+1):
        d = rad * i
        p += int(r * cos(d)) + x, int(r * sin(d)) + y
    p += x+r, y # adding end of fan
    return b.add_indexed(n+2, pyglet.gl.GL_TRIANGLES, None, index, ('v2i', p), ('c3B', (c+c[-3:])))

def vec(*args):
    return (GLfloat * len(args))(*args)

def gl_setup1():

    # One-time GL setup
    glClearColor(0.5, 0.5, 0.5, 1)
    glColor3f(1, 1, 1)
    glEnable(GL_DEPTH_TEST)
    glEnable(GL_CULL_FACE)
    glEnable(GL_BLEND)
    glDisable(GL_TEXTURE_2D)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE)


    # Simple light setup.  On Windows GL_LIGHT0 is enabled by default,
    # but this is not the case on Linux or Mac, so remember to always 
    # include it.
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    glEnable(GL_LIGHT1)

    glHint(GL_LINE_SMOOTH_HINT,GL_NICEST)
    glHint(GL_POLYGON_SMOOTH_HINT,GL_NICEST)

    #glEnable(GL_TEXTURE_2D)

    #glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, vec(0.8, 0.5, 0.5, 1.0))
    #glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, vec(1, 1, 1, 1))
    #glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 50)

    #glMaterialfv(GL_FRONT, GL_DIFFUSE, initdiffuse)
    glMaterialfv(GL_FRONT, GL_AMBIENT, vec(0, 0, 0, 0));
    glMaterialfv(GL_FRONT, GL_DIFFUSE, vec(1, 1, 1, 1));
